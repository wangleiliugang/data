def myfun3():
    print("myfun3()被调用")

print("mymodule3被加载")

def myfun4():
    print("myfun4()被调用")
    