# 练习：修改之前的学生管理系统
# 原学生数据使用字典存储，现改为用对象进行存储，要求自定义Student类来封装学生的信息和行为

# file: student_exercise.py
class Student:
    def __init__(self, n, a, s):
        self.name = n
        self.age = a
        self.score = s
        


# 详解见student_.._83.py
