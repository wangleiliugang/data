import sys

sys.stdout.write('hello world\n')

sys.stdout.write('它的出现是个错误！\n')