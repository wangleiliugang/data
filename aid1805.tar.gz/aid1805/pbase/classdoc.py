'''这是模块的标题

此模块示意类的文档字符串
'''
class Car:
    '''此类用来描述车的对象的行为
    这是Car类的文档字符串'''
    def run(self, speed):
        '''车的run方法'''
        pass

        