# 此模块是用户自定义模块
def myfun1():
    print("正在调用mymodule1里的myfun1()")

def myfun2():
    print("mymodule1里的myfun2()")

name1 = 'audi'
name2 = 'tesla'

