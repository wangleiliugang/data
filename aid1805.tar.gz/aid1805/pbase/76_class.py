# 此示例示意　类　的定义

class Dog:  # 定义一个类，类名是Dog
    pass

dog1 = Dog()   # 创建Dog类的对象
print(id(dog1))
dog2 = Dog()   # 创建Dog类的另一个对象
print(id(dog2))

# 类似如下语句：
int1 = int()
int2 = int()