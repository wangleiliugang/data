

r = 3
pi = 3.1415926
length = 2* pi *r
area = pi * r **2
print("这个圆的周长是：",length)
print("这个圆的面积是：",area)

