# 练习1
# 把学生管理系统划分为模块(把相关操作放在一个模块内):
# 建议：main_student.py 放主事件循环
# 　　　　　menu_student.py 放show_menu函数
# 　　　　　project_student.py 放学生信息相关的操作

# 程序详见：　main_student.py　+　menu_student.py　+　project_student.py
