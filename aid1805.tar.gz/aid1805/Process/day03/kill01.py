import os
import signal

os.kill(4100, signal.SIGKILL)
