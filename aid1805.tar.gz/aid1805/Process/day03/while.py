#!/usr/bin/python3

import time

while True:
    time.sleep(3)
    print("process is running")
