import time


def fun1():
    time.sleep(6)
    print("做完第一件事")


def fun2():
    time.sleep(4)
    print("做完第二件事")

# fun1()
# fun2()
