---
id: golang
title: Golang
sidebar_label: Golang
---

## What

Display the currently active golang version.

## Sample Configuration

```json
{
  "type": "go",
  "style": "powerline",
  "powerline_symbol": "\uE0B0",
  "foreground": "#ffffff",
  "background": "#7FD5EA",
  "properties": {
    "prefix": " \uFCD1 "
  }
}
```

## Properties

- display_version: `boolean` - display the golang version - defaults to `true`
- display_error: `boolean` - show the error context when failing to retrieve the version information - defaults to `true`
- missing_command_text: `string` - text to display when the command is missing - defaults to empty
- display_mode: `string` - determines when the segment is displayed
  - `always`: the segment is always displayed
  - `files`: the segment is only displayed when `*.go` or `go.mod` files are present (default)
