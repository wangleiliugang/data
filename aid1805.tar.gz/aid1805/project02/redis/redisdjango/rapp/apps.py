from django.apps import AppConfig


class RappConfig(AppConfig):
    name = 'rapp'
