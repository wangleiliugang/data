import sys

# 收集命令行信息：以空格为分隔收集命令行选项，存储在一个列表中
print(sys.argv)
print(sys.argv[1])
print(sys.argv[2])
